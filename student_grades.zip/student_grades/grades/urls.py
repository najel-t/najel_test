from django.urls import path
from . import views

urlpatterns = [
    path('', views.student_grade_view, name='student_grade_view'),
]
