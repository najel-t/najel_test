from django.shortcuts import render, redirect, get_object_or_404
from .models import Student, Subject, Grade
from django.db.models import Q

def student_grade_view(request):
    if request.method == "POST":
        if 'add_student' in request.POST:
            student_name = request.POST.get('student_name')
            if student_name:
                Student.objects.create(student_name=student_name)
        elif 'add_subject' in request.POST:
            subject_name = request.POST.get('subject_name')
            if subject_name:
                Subject.objects.create(subject_name=subject_name)
        elif 'add_grade' in request.POST:
            student_key = request.POST.get('student')
            subject_key = request.POST.get('subject')
            grade = request.POST.get('grade')
            try:
                student = Student.objects.get(student_key=student_key)
                subject = Subject.objects.get(subject_key=subject_key)
                if grade.isdigit():
                    grade = int(grade)
                    Grade.objects.create(student=student, subject=subject, grade=grade)
            except (Student.DoesNotExist, Subject.DoesNotExist):
               
                pass
        elif 'delete' in request.POST:
            model_type = request.POST.get('model_type')
            item_id = request.POST.get('item_id')
            if model_type == 'student':
                student = get_object_or_404(Student, pk=item_id)
                student.delete()
            elif model_type == 'subject':
                subject = get_object_or_404(Subject, pk=item_id)
                subject.delete()
            elif model_type == 'grade':
                grade = get_object_or_404(Grade, pk=item_id)
                grade.delete()

        return redirect('student_grade_view')

    search_query = request.GET.get('search', '')
    filter_criteria = request.GET.get('filter', 'all')

    grades_query = Grade.objects.all()
    if search_query:
        grades_query = grades_query.filter(student__student_name__icontains=search_query)
    if filter_criteria != 'all':
        grades_query = grades_query.filter(remarks=filter_criteria.upper())

    students = Student.objects.all()
    subjects = Subject.objects.all()
    grades = grades_query

    return render(request, 'grades/student_grade_view.html', {
        'students': students,
        'subjects': subjects,
        'grades': grades,
    })
